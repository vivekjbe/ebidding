package com.bidding.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbiddingBuyerService1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
