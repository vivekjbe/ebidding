package com.bidding.buyservice.dao;

import org.springframework.stereotype.Component;

import com.bidding.buyservice.dto.BidInformationDTO;
import com.bidding.buyservice.model.BidInformation;
import com.bidding.buyservice.model.ProductInfo;

@Component
public interface BuyerRepository {

	ProductInfo getProductInformation(String productId);

	BidInformationDTO getBidInformation(String productId, String buyerEmailId);

	String updateBidInformation(String productId, String buyerEmailId, int newBidAmount);
	
	String placeBid(BidInformation bid);
}
