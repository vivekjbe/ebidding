package com.bidding.buyservice.controller;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bidding.buyservice.model.BidInformation;
import com.bidding.buyservice.service.BuyerService;
import com.bidding.buyservice.utils.BidDateException;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(path="/e-auction/api/v1")
public class BuyerController {

	static Logger logger = Logger.getLogger(BuyerController.class.getName());

	@Autowired
	BuyerService buyerService;

	@PutMapping(path="/buyer/update-bid/{productId}/{buyerEmailId}/{newBidAmount}")
	public String updateBidController(@PathVariable String productId, @PathVariable String buyerEmailId,
			@PathVariable int newBidAmount) throws BidDateException {
		logger.info("updateBidController Starts Here");
		if (productId == null && buyerEmailId == null) {
			return "ProductID, EmailID and BidAmount should not null";
		}
		return buyerService.updateBid(productId, buyerEmailId, newBidAmount);
	}
	
	@PostMapping(path="/buyer/place-bid")
	public String placeBid(@RequestBody BidInformation bid){
		logger.info("updateBidController Starts Here");
		return buyerService.placeBid(bid);
	}
}
