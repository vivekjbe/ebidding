package com.bidding.buyservice.utils;

public class BidDateException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BidDateException(String str) {
		super(str);
	}
}
