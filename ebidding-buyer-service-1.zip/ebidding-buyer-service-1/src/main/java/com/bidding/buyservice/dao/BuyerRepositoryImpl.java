package com.bidding.buyservice.dao;

import java.util.logging.Logger;

import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Repository;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.UpdateItemOutcome;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.bidding.buyservice.dto.BidInformationDTO;
import com.bidding.buyservice.model.BidInformation;
import com.bidding.buyservice.model.ProductInfo;
import com.bidding.buyservice.utils.Constants;

@Repository
public class BuyerRepositoryImpl implements BuyerRepository {

	static Logger logger = Logger.getLogger(BuyerRepositoryImpl.class.getName());

	AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
			.withEndpointConfiguration(
					new AwsClientBuilder.EndpointConfiguration(
							"dynamodb.us-east-1.amazonaws.com", 
							"us-east-1"))
			.withCredentials(new AWSStaticCredentialsProvider(
					new BasicAWSCredentials("AKIAZLNUET2AXTERWG5X", "M36WHlZ0kCp3DfJQ/AIGt88AgCrEpLrl3z1G+6um")))
			.build();

	DynamoDBMapper mapper = new DynamoDBMapper(client);
	DynamoDB dynamoDB = new DynamoDB(client);

	public ProductInfo getProductInformation(String productId) {
		return mapper.load(ProductInfo.class, productId);
	}

	public BidInformationDTO getBidInformation(String productId, String buyerEmailId) {
		logger.info("getBidInformation repository layer Starts Here");
		BidInformation bidInformation = new BidInformation();
		bidInformation.setEmail(buyerEmailId);
		bidInformation.setProductId(productId);

		BidInformation bidInformationDB = mapper.load(bidInformation,
				new DynamoDBMapperConfig(DynamoDBMapperConfig.ConsistentReads.CONSISTENT));
		if (bidInformationDB != null) {
			DozerBeanMapper dozerBeanMapper = new DozerBeanMapper();
			BidInformationDTO bidInformationResponse = dozerBeanMapper.map(bidInformationDB, BidInformationDTO.class);
			return bidInformationResponse;
		}
		return null;
	}

	public String updateBidInformation(String productId, String buyerEmailId, int newBidAmount) {

		logger.info("updateBidInformation repository layer Ends Here ");
		Table table = dynamoDB.getTable("BidInformation");
		UpdateItemSpec updateItemSpec = new UpdateItemSpec()
				.withPrimaryKey("Email", buyerEmailId, "ProductId", productId)
				.withUpdateExpression("set BidAmount = :r").withValueMap(new ValueMap().withNumber(":r", newBidAmount))
				.withReturnValues(ReturnValue.UPDATED_NEW);
		try {
			UpdateItemOutcome outcome = table.updateItem(updateItemSpec);
			return Constants.SUCCESS;
		} catch (Exception e) {
			logger.info("updateBidInformation repository Exception " + e.getMessage());
			return Constants.FAILED;
		}
	}

	public String placeBid(BidInformation bidDTO) {
		DozerBeanMapper dozerBeanMapper = new DozerBeanMapper();
		BidInformation biddingInfo = dozerBeanMapper.map(bidDTO, BidInformation.class);
		mapper.save(biddingInfo);
		return "Bid Placed sucessfully";
	}

}
