package com.bidding.buyservice.service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bidding.buyservice.dao.BuyerRepository;
import com.bidding.buyservice.dto.BidInformationDTO;
import com.bidding.buyservice.model.BidInformation;
import com.bidding.buyservice.model.ProductInfo;
import com.bidding.buyservice.utils.BidDateException;

@Service
public class BuyerServiceImpl implements BuyerService {

	static Logger logger = Logger.getLogger(BuyerServiceImpl.class.getName());

	@Autowired
	BuyerRepository buyerRepository;

	public String updateBid(String productId, String buyerEmailId, int newBidAmount) throws BidDateException {
		logger.info("updateBid Service Layer Starts Here");
		ProductInfo productInfo = buyerRepository.getProductInformation(productId);
		BidInformationDTO bidInformation = buyerRepository.getBidInformation(productId, buyerEmailId);
		if (bidInformation == null) {
			return "Bid Information Not Available";
		}
		LocalDate now = LocalDate.now();
		LocalDate bidDate = LocalDate.parse(productInfo.getBidEndDate());
		if (productInfo.getBidEndDate() != null && now.isAfter(bidDate)) {
			throw new BidDateException("Bid Date is Closed");
		}
		return buyerRepository.updateBidInformation(productId, buyerEmailId, newBidAmount);
	}

	public String placeBid(BidInformation bid) {
		logger.info("placeBid Service Layer Starts Here");
		return buyerRepository.placeBid(bid);
	}

}
