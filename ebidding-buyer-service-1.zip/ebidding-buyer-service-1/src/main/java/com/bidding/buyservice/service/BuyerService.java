package com.bidding.buyservice.service;

import org.springframework.stereotype.Component;

import com.bidding.buyservice.model.BidInformation;
import com.bidding.buyservice.utils.BidDateException;

@Component
public interface BuyerService {
	String updateBid(String productId, String buyerEmailId, int newBidAmount) throws BidDateException;
	String placeBid(BidInformation bid);
}
