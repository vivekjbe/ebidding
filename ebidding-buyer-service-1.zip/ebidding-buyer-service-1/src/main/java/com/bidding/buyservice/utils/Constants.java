package com.bidding.buyservice.utils;

public class Constants {

	public static String SUCCESS = "Success";
	public static String FAILED = "Failed";
}
