package com.bidding.sellservice.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class Products {
	
	private String id;
	private String value;

}
