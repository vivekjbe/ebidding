package com.bidding.sellservice.utils;

public class BidDateException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BidDateException(String str) {
		super(str);
	}
}
